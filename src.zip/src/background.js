// Simple background script - no special handling needed for popup-based approach
console.log('Gmail Smart Compose extension loaded');
